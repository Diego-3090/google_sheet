const NewSheets_URL = "https://docs.google.com/spreadsheets/d/e/2PACX-1vSTUGj0FvHIdwxHRoKjfEsf-Hpbx1hh2wnSAOqwKK-tsdlT8BC-pqBGx2kwtVdmcdJa85Vyk8FD5BKB/pub?gid=0&single=true&output=csv";

document.addEventListener('DOMContentLoaded', (event) => {
    cualquiera();
});

function cualquiera() {
    fetch(NewSheets_URL)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la respuesta de red');
            }
            return response.text();
        })
        .then(data => {
            console.log('Datos CSV:', data);
            const parsedData = parseCSV(data);
            console.log('Datos obtenidos:', parsedData);
            displayTable(parsedData);
        })
        .catch(error => console.error('Error al cargar el archivo CSV:', error));
}

function parseCSV(data) {
    const rows = data.split('\n').filter(row => row.trim() !== '');
    const headers = rows[0].split(',');
    return rows.slice(1).map(row => {
        const values = row.split(',');
        let obj = {};
        headers.forEach((header, index) => {
            obj[header.trim()] = values[index] ? values[index].trim() : '';
        });
        return obj;
    });
}

function displayTable(data) {
    if (!data.length) {
        console.error('No hay datos para mostrar en la tabla');
        return;
    }

    const table = document.createElement('table');
    const thead = document.createElement('thead');
    const tbody = document.createElement('tbody');
    
    const headers = Object.keys(data[0]);
    const tr = document.createElement('tr');
    headers.forEach(header => {
        const th = document.createElement('th');
        th.textContent = header;
        tr.appendChild(th);
    });
    thead.appendChild(tr);
    table.appendChild(thead);
    
    data.forEach(row => {
        const tr = document.createElement('tr');
        headers.forEach(header => {
            const td = document.createElement('td');
            td.textContent = row[header];
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    
    const tableContainer = document.getElementById('table-container');
    tableContainer.innerHTML = '';
    tableContainer.appendChild(table);
}