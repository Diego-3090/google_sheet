const SHEET_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vQHucQ8_rWSHRiRSXY7sWVG7uYdIYIuwB-gra_HzO2VhDcq2MCNb9IJe4WyFs_ydXnMQpMblOFkTTtP/pub?gid=0&single=true&output=csv';

function verificar() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    console.log('Usuario ingresado:', username);
    console.log('Contraseña ingresada:', password);

    fetch(SHEET_URL)
        .then(response => response.text())
        .then(data => {
            console.log('Datos CSV:', data);  
            const parsedData = parseCSV(data);
            console.log('Datos obtenidos:', parsedData);

            parsedData.forEach(user => {
                console.log('Comparando:', user.Correo, '===', username, '&&', user.Contraseña, '===', password);
            });

            const usuarioValido = parsedData.find(u => {
                return u.Correo === username && u.Contraseña === password;
            });

            console.log('Usuario válido:', usuarioValido);
            if (usuarioValido) {
                
                localStorage.setItem('nombreUsuario', usuarioValido.Correo);
                window.location.href = "http://localhost/adelanto/html/accedido.html";
            } else {
                console.log('Usuario o contraseña incorrectos.');
                alert("Usuario o contraseña incorrectos.");
                limpiar();
            }
        })
        .catch(error => console.error('Error al cargar el archivo CSV:', error));
}

function parseCSV(data) {
    const rows = data.split('\n');
    const headers = rows[0].split(',');
    return rows.slice(1).map(row => {
        const values = row.split(',');
        let obj = {};
        headers.forEach((header, index) => {
            obj[header.trim()] = values[index].trim();
        });
        return obj;
    });
}

function limpiar() {
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}













